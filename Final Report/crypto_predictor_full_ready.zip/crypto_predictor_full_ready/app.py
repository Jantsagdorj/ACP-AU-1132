from flask import Flask, request, render_template, jsonify
from utils.api import fetch_historical_data, fetch_current_price
from utils.model import train_and_predict  # uses XGBoost internally
import pandas as pd

app = Flask(__name__)

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/prediction')
def prediction():
    return render_template("prediction.html")


@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        coin = data.get('coin', 'bitcoin')
        days = int(data.get('days', 7))

        df = pd.read_csv(f"data/{coin}_1y.csv")
        df['date'] = pd.to_datetime(df['date'])
        current_price = df['price'].iloc[-1]

        forecast = train_and_predict(df, current_price=current_price, future_days=days)
        return jsonify({"status": "success", "data": forecast.to_dict(orient='records')})
    except Exception as e:
        print("❌ Prediction error:", e)
        return jsonify({"status": "error", "message": str(e)})


@app.route('/current_price/<coin_id>')
def current_price(coin_id):
    try:
        price = fetch_current_price(coin_id)
        return jsonify({'status': 'success', 'price': price})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})

@app.route('/get_data', methods=['POST'])
def get_data():
    try:
        import pandas as pd
        data = request.json or {}
        coin = data.get('coin', 'bitcoin')
        time_range = data.get('range', '1y')

        range_map = {'7d': 7, '1m': 30, '6m': 180, '1y': 365}
        days = range_map.get(time_range, 365)

        df = pd.read_csv(f'data/{coin}_1y.csv')  # ✅ Only load the full CSV
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date')

        # ✅ Slice latest N days based on selected range
        df = df.tail(days)

        return jsonify({'status': 'success', 'data': df.to_dict(orient='records')})
    except Exception as e:
        print("⚠️ CSV fetch failed:", e)
        return jsonify({'status': 'error', 'message': str(e)})
    

if __name__ == '__main__':
    app.run(debug=True)
