import os
import time
import requests
import pandas as pd

# 📁 Where to store data
os.makedirs("data", exist_ok=True)

# Coins and time range
coins = ['bitcoin', 'ethereum', 'dogecoin']
range_map = {'1y': 365}
vs_currency = 'usd'

def fetch_historical_data(coin_id, days):
    url = f"https://api.coingecko.com/api/v3/coins/{coin_id}/market_chart"
    params = {
        'vs_currency': vs_currency,
        'days': days,
        'interval': 'daily'
    }
    response = requests.get(url, params=params)
    response.raise_for_status()
    data = response.json()

    df = pd.DataFrame(data['prices'], columns=['timestamp', 'price'])
    df['date'] = pd.to_datetime(df['timestamp'], unit='ms')
    return df[['date', 'price']]

# 🔁 Loop through each coin and save
for coin in coins:
    try:
        print(f"Fetching data for {coin}...")
        df = fetch_historical_data(coin, days=365)
        df.to_csv(f"data/{coin}_1y.csv", index=False)
        print(f"✅ Saved: data/{coin}_1y.csv")
        time.sleep(1.5)  # Prevent rate limiting
    except Exception as e:
        print(f"❌ Failed for {coin}: {e}")
