import requests
import pandas as pd
import time
from datetime import datetime, timedelta

import os


def fetch_historical_data(time_range='1y', coin_id='bitcoin', vs_currency='usd'):
    range_map = {'7d': 7, '1m': 30, '6m': 180, '1y': 365}
    days = range_map.get(time_range, 365)

    try:
        # Always use the 1y CSV
        filepath = f"data/{coin_id}_1y.csv"
        df = pd.read_csv(filepath)

        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date')

        # Get only the last `days` worth of data
        recent_df = df.tail(days).copy()
        return recent_df[['date', 'price']]

    except Exception as e:
        print(f"⚠️ CSV fetch failed: {e}")
        return pd.DataFrame(columns=['date', 'price'])

def fetch_current_price(coin_id='bitcoin', vs_currency='usd'):
    try:
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {
            'ids': coin_id,
            'vs_currencies': vs_currency
        }
        response = requests.get(url, params=params, timeout=3)
        response.raise_for_status()

        price_data = response.json()
        if not isinstance(price_data, dict):
            raise ValueError("Invalid price data format")

        return price_data.get(coin_id, {}).get(vs_currency, None)

    except Exception as e:
        print("⚠️ Price fetch failed:", e)
        return None
