import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from xgboost import XGBRegressor

def train_and_predict(df, current_price=None, future_days=7, window_size=5):
    df = df.copy()

    for i in range(1, window_size + 1):
        df[f'lag_{i}'] = df['price'].shift(i)
    df.dropna(inplace=True)

    X = df[[f'lag_{i}' for i in range(1, window_size + 1)]]
    y = df['price']

    model = XGBRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)

    last_window = df['price'].values[-window_size:]
    if current_price is not None:
        last_window[-1] = current_price

    preds, lows, highs = [], [], []
    for i in range(future_days):
        X_new = last_window[-window_size:].reshape(1, -1)
        base = model.predict(X_new)[0]

        noise = np.random.normal(0, 0.01 * base)
        drift = 0.001 * i * base
        pred = base + noise + drift

        preds.append(round(pred, 2))
        lows.append(round(pred * 0.985, 2))
        highs.append(round(pred * 1.015, 2))

        last_window = np.append(last_window[1:], pred)

    # Generate dates
    dates = [datetime.now() + timedelta(days=i) for i in range(future_days)]

    # ⏱ Prepend current price to the beginning
    if current_price is not None:
        dates.insert(0, datetime.now())
        preds.insert(0, round(current_price, 2))
        lows.insert(0, round(current_price * 0.985, 2))
        highs.insert(0, round(current_price * 1.015, 2))

    return pd.DataFrame({'date': dates, 'price': preds, 'min': lows, 'max': highs})
